import { SupportPage } from '@/pages/support';
import { WalletRoutes } from '@/pages/wallet-routes';
import { DogRacingPage } from '@/pages/games/dog-racing';
import { ThunderDerbyPage } from '@/pages/games/thunder-derby';
import { VirtualFootballPage } from '@/pages/games/virtual-football';
import { CryptoPaymentsPage } from '@/pages/crypto-payments';
import { CreateAgentPage, ActivateAgentPage } from '@/pages/workspaces/create-agent';
import {
  WorkspaceDestination,
  WorkspaceGate,
  WorkspaceLayout,
  AdminOverview,
  AdminAccounts,
  AdminRecords,
  AgentOverview,
  WorkspaceProcessing,
} from '@/pages/workspaces';
import { WalletSetupAdmin } from '@/pages/wallet-setup-admin';
import { WalletPricingAdmin } from '@/pages/wallet-pricing-admin';
import { WalletAgentSetupPage } from '@/pages/wallet-agent-setup';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { useAuth } from '@/providers/auth-provider';
import { Layout } from '@/components/layout/layout';
import { HomePage } from '@/pages/home';
import { WelcomePage, ExplorePage } from '@/pages/welcome';
import { LoginPage } from '@/pages/login';
import { RegisterPage } from '@/pages/register';
import { ProtectedRoute } from '@/components/auth/protected-route';
import { CasinoProvider } from '@/components/casino/CasinoProvider';
import { GamesPage } from '@/pages/games';
import { CasinoPage } from '@/pages/casino';
import { SportsPage } from '@/pages/sports';
import { SportsLaunchPage } from '@/pages/sports-launch';
import { SkyCrashPage } from '@/pages/games/sky-crash';
import { CrashPointPage } from '@/pages/games/crash-point';
import { SystemDicePage } from '@/pages/games/dice-system';
import { LuckySpinPage } from '@/pages/games/lucky-spin';
import { SpinWinScheduledPage } from '@/pages/games/spin-win-scheduled';
import { SystemKenoPage } from '@/pages/games/keno-system';
import { BlackjackPage } from '@/pages/games/blackjack';
import { LuckySixPage } from '@/pages/games/lucky-six';
import { RouletteKenoPage } from '@/pages/games/roulette-keno';
import { SpinWinCoinsPage } from '@/pages/games/spin-win-coins';
import { NumberChallengePage } from '@/pages/games/number-challenge';
import { GameComingSoonPage } from '@/pages/games/coming-soon';
import { GameHistoryPage } from '@/pages/games/history';
import { ChallengesPage } from '@/pages/challenges';
import { ChallengeDetailPage } from '@/pages/challenges/detail';
import { CompetitionsPage } from '@/pages/competitions';
import { GroupCompetitionsPage } from '@/pages/competitions/index';
import { CompetitionDetailPage } from '@/pages/competitions/detail';
import { GroupsPage } from '@/pages/groups';
import { GroupDetailPage } from '@/pages/group-detail';
import { GroupInviteAcceptPage } from '@/pages/group-invite-accept';
import { MessagesPage } from '@/pages/messages';
import { GroupGamesPage } from '@/pages/group-games';
import { PlayTogetherPage } from '@/pages/play-together';
import { GroupPlayControlPage } from '@/pages/workspaces/group-play-control';
import { GroupGiftsPage } from '@/pages/group-gifts';
import { MemberRewardsPage } from '@/pages/member-rewards';
import { RewardControlPage } from '@/pages/workspaces/reward-control';
import { ProfilePage } from '@/pages/profile';

import { PasswordResetPage } from '@/pages/password-reset';
import { AdminAgents } from '@/pages/workspaces/agents';
import { AdminAccountDetail } from '@/pages/workspaces/account-detail';
import { useLanguage as useInterfaceLanguage } from '@/providers/language-provider';

// Keep pairing-verification code out of the normal casino entry bundle.
const SpinWinVerifyPage = lazy(async () => {
  const page = await import('@/pages/games/spin-win-verify');
  return { default: page.SpinWinVerifyPage };
});

export function App() {
  const { t: translateUi } = useInterfaceLanguage();

  const { isLoading } = useAuth();
  const location = useLocation();

  // Public sign-in/activation, discovery and offline verification must remain
  // reachable while the unrelated session probe is waiting on an unavailable API.
  if (
    isLoading &&
    !/^\/(?:explore\/?|login\/?|register\/?|reset-password\/?|(?:admin\/login|agent\/(?:login|activate))\/?|games\/spin-win\/verify\/?)?$/.test(
      location.pathname
    )
  ) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<WelcomePage />} />
      <Route path="/explore" element={<ExplorePage />} />
      <Route
        path="/games/spin-win/verify"
        element={
          <Suspense
            fallback={
              <main className="min-h-screen bg-slate-950 p-8 text-slate-100">
                {translateUi('Loading round verifier…')}
              </main>
            }
          >
            <SpinWinVerifyPage />
          </Suspense>
        }
      />
      <Route path="/admin/login" element={<LoginPage workspace="admin" />} />
      <Route path="/reset-password" element={<PasswordResetPage />} />
      <Route path="/agent/activate" element={<ActivateAgentPage />} />
      <Route path="/agent/login" element={<LoginPage workspace="agent" />} />
      <Route
        path="/admin"
        element={
          <WorkspaceGate kind="admin">
            <WorkspaceLayout kind="admin" />
          </WorkspaceGate>
        }
      >
        <Route index element={<AdminOverview />} />
        <Route path="support" element={<SupportPage admin />} />
        <Route path="rewards" element={<RewardControlPage />} />
        <Route path="group-play" element={<GroupPlayControlPage />} />
        <Route path="payments" element={<WalletSetupAdmin />} />
        <Route path="agents/new" element={<CreateAgentPage />} />
        <Route path="agents" element={<AdminAgents />} />
        <Route path="crypto" element={<CryptoPaymentsPage admin />} />
        <Route path="pricing" element={<WalletPricingAdmin />} />
        <Route path="disputes" element={<WorkspaceProcessing kind="admin" />} />
        <Route path="accounts" element={<AdminAccounts />} />
        <Route path="accounts/:id" element={<AdminAccountDetail />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="games" element={<AdminRecords kind="games" />} />
        <Route path="activity" element={<AdminRecords kind="audit" />} />
        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Route>
      <Route
        path="/agent"
        element={
          <WorkspaceGate kind="agent">
            <WorkspaceLayout kind="agent" />
          </WorkspaceGate>
        }
      >
        <Route index element={<AgentOverview />} />
        <Route path="operations" element={<WorkspaceProcessing kind="agent" />} />
        <Route path="accounts" element={<WalletAgentSetupPage workspace />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="support" element={<SupportPage />} />
        <Route path="*" element={<Navigate to="/agent" replace />} />
      </Route>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route path="dashboard" element={<HomePage />} />
        <Route path="groups" element={<GroupsPage />} />
        <Route path="groups/invite/:token" element={<GroupInviteAcceptPage />} />
        <Route path="groups/:id" element={<GroupDetailPage />} />
        <Route path="messages" element={<MessagesPage />} />
        <Route path="messages/:groupId" element={<MessagesPage />} />
        <Route path="groups/:id/games" element={<PlayTogetherPage />} />
        <Route path="groups/:id/games/legacy" element={<GroupGamesPage />} />
        <Route path="play-together" element={<PlayTogetherPage />} />
        <Route path="play-together/rounds/:roundId" element={<PlayTogetherPage />} />
        <Route path="groups/:id/gifts" element={<GroupGiftsPage />} />
        <Route path="gifts" element={<GroupGiftsPage />} />
        <Route path="wallet/operations" element={<WorkspaceDestination />} />
        <Route path="wallet/*" element={<WalletRoutes />} />
        <Route path="rewards" element={<MemberRewardsPage />} />
        <Route path="support" element={<SupportPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="games" element={<PlayTogetherPage />} />
        <Route path="games/practice" element={<GamesPage />} />
        <Route path="casino" element={<CasinoPage />} />
        <Route path="sports" element={<SportsPage />} />
        <Route path="sports/open" element={<SportsLaunchPage />} />
        <Route path="games/history" element={<GameHistoryPage />} />
        <Route path="games/provider-demos" element={<Navigate to="/casino" replace />} />
        <Route
          path="games/dice"
          element={
            <CasinoProvider>
              <SystemDicePage />
            </CasinoProvider>
          }
        />
        <Route path="games/lucky-spin" element={<LuckySpinPage />} />
        <Route path="games/spin-win/live" element={<SpinWinScheduledPage />} />
        <Route path="games/spin-win" element={<SpinWinScheduledPage />} />
        <Route path="games/dog-racing" element={<DogRacingPage />} />
        <Route path="games/thunder-derby" element={<ThunderDerbyPage />} />
        <Route path="games/virtual-football" element={<VirtualFootballPage />} />
        <Route path="games/sky-crash" element={<SkyCrashPage />} />
        <Route
          path="games/crash-point"
          element={
            <CasinoProvider>
              <CrashPointPage />
            </CasinoProvider>
          }
        />
        <Route
          path="games/turbo-keno"
          element={
            <CasinoProvider>
              <SystemKenoPage />
            </CasinoProvider>
          }
        />
        <Route path="games/blackjack" element={<BlackjackPage />} />
        <Route path="games/lucky-six" element={<LuckySixPage />} />
        <Route path="games/roulette-keno" element={<RouletteKenoPage />} />
        <Route
          path="games/spin-win/play"
          element={
            <CasinoProvider>
              <SpinWinCoinsPage />
            </CasinoProvider>
          }
        />
        <Route
          path="games/number-challenge"
          element={
            <CasinoProvider>
              <NumberChallengePage />
            </CasinoProvider>
          }
        />
        <Route path="games/trivia" element={<GameComingSoonPage name="Trivia" />} />
        <Route path="challenges" element={<ChallengesPage />} />
        <Route path="challenges/:id" element={<ChallengeDetailPage />} />
        <Route path="competitions" element={<CompetitionsPage />} />
        <Route path="competitions/:groupId" element={<GroupCompetitionsPage />} />
        <Route path="competitions/:groupId/:competitionId" element={<CompetitionDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
